package com.example.lab01

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ContadorView() {
    // 🎯 EXPLICAR: Estado local con remember
    var contador by remember { mutableIntStateOf(0) }
    var totalClicks by remember { mutableIntStateOf(0) }

    // 🎯 EXPLICAR: Color dinámico según el valor
    val colorContador = when {
        contador > 0 -> Color(0xFF4CAF50)  // Verde
        contador < 0 -> Color(0xFFF44336)  // Rojo
        else -> Color.Gray
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Título
        Text(
            text = "Contador Simple",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Tarjeta del contador
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Valor Actual",
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = contador.toString(),
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Bold,
                    color = colorContador
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Fila de botones principales
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Botón -1
            Button(
                onClick = {
                    contador--
                    totalClicks++
                },
                modifier = Modifier.width(100.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("-1", fontSize = 20.sp)
            }

            // Botón +1
            Button(
                onClick = {
                    contador++
                    totalClicks++
                },
                modifier = Modifier.width(100.dp)
            ) {
                Text("+1", fontSize = 20.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botón RESET
        OutlinedButton(
            onClick = {
                contador = 0
                totalClicks++
            },
            modifier = Modifier.width(216.dp)
        ) {
            Text("RESET")
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Estadísticas
        Text(
            text = "Total de clicks: $totalClicks",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}