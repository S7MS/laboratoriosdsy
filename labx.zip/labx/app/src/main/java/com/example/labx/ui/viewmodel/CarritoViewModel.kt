package com.example.labx.ui.viewmodel


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.labx.data.local.AppDatabase
import com.example.labx.data.repository.CarritoRepository
import com.example.labx.domain.model.Producto
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * ViewModel que gestiona la lógica de UI
 * AndroidViewModel provee Context para Database
 */
class CarritoViewModel(application: Application) : AndroidViewModel(application) {

    // Repository
    private val repository: CarritoRepository

    init {
        val database = AppDatabase.getDatabase(application)
        val dao = database.carritoDao()
        repository = CarritoRepository(dao)
    }

    // StateFlow para productos disponibles (hardcoded para este lab)
    val productosDisponibles = listOf(
        Producto(id = 1, nombre = "Mouse Gamer", precio = 25000),
        Producto(id = 2, nombre = "Teclado Mecánico", precio = 45000),
        Producto(id = 3, nombre = "Audífonos RGB", precio = 35000)
    )

    // StateFlow para items en carrito (observa cambios en Room)
    val itemsCarrito: StateFlow<List<Producto>> = repository.obtenerCarrito()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // StateFlow para total del carrito
    val totalCarrito: StateFlow<Int> = repository.obtenerTotal()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    /**
     * Agrega un producto al carrito
     */
    fun agregarAlCarrito(producto: Producto) {
        viewModelScope.launch {
            repository.agregarProducto(producto)
        }
    }

    /**
     * Vacía el carrito completo
     */
    fun vaciarCarrito() {
        viewModelScope.launch {
            repository.vaciarCarrito()
        }
    }
}