package com.example.labx.data.repository



import com.example.labx.data.local.dao.CarritoDao
import com.example.labx.data.local.entity.CarritoEntity
import com.example.labx.data.local.entity.toDomain
import com.example.labx.domain.model.Producto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Repository centraliza el acceso a datos
 * Abstrae la fuente de datos (Room) del ViewModel
 */
class CarritoRepository(private val carritoDao: CarritoDao) {

    /**
     * Obtiene todos los productos del carrito
     * Convierte entities a modelos de dominio
     */
    fun obtenerCarrito(): Flow<List<Producto>> {
        return carritoDao.obtenerTodo()
            .map { entities -> entities.map { it.toDomain() } }
    }

    /**
     * Agrega un producto al carrito
     */
    suspend fun agregarProducto(producto: Producto) {
        val entity = CarritoEntity(
            productoId = producto.id,
            nombre = producto.nombre,
            precio = producto.precio
        )
        carritoDao.insertar(entity)
    }

    /**
     * Vacía el carrito completo
     */
    suspend fun vaciarCarrito() {
        carritoDao.vaciar()
    }

    /**
     * Obtiene el total del carrito
     * map convierte null a 0
     */
    fun obtenerTotal(): Flow<Int> {
        return carritoDao.obtenerTotal()
            .map { it ?: 0 }
    }
}