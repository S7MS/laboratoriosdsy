package com.example.labx.domain.model



/**
 * Modelo de dominio para Producto
 * NO tiene anotaciones de Room
 */
data class Producto(
    val id: Long,
    val nombre: String,
    val precio: Int // Precio en pesos chilenos
) {
    /**
     * Formatea el precio con separador de miles
     * Ejemplo: 25000 -> "$25.000"
     */
    fun precioFormateado(): String {
        return "$${precio.toString().reversed().chunked(3).joinToString(".").reversed()}"
    }
}