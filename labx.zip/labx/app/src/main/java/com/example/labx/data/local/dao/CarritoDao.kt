package com.example.labx.data.local.dao


import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.labx.data.local.entity.CarritoEntity
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object para tabla carrito
 * Define las operaciones SQL disponibles
 */
@Dao
interface CarritoDao {

    /**
     * Obtiene todos los items del carrito en tiempo real
     * Flow emite nuevos valores cuando cambia la tabla
     */
    @Query("SELECT * FROM carrito")
    fun obtenerTodo(): Flow<List<CarritoEntity>>

    /**
     * Inserta un nuevo producto al carrito
     * suspend = operación asíncrona
     */
    @Insert
    suspend fun insertar(item: CarritoEntity)

    /**
     * Elimina todos los items del carrito
     */
    @Query("DELETE FROM carrito")
    suspend fun vaciar()

    /**
     * Calcula el total sumando todos los precios
     * Flow para observar cambios en tiempo real
     */
    @Query("SELECT SUM(precio) FROM carrito")
    fun obtenerTotal(): Flow<Int?>
}