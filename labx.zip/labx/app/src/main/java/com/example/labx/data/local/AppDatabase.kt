package com.example.labx.data.local



import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.labx.data.local.dao.CarritoDao
import com.example.labx.data.local.entity.CarritoEntity

/**
 * Database principal de la app
 * Singleton para una única instancia en toda la app
 */
@Database(
    entities = [CarritoEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    /**
     * Provee acceso al DAO
     */
    abstract fun carritoDao(): CarritoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Obtiene instancia única de la base de datos
         * Thread-safe con synchronized
         */
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "carrito_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}