package com.example.lab02

// Sealed class para definir todas las rutas de la app
sealed class AppRoutes(val route: String) {
    // Pantalla principal (Home)
    data object HomeScreen : AppRoutes("home")

    // Pantalla de perfil con argumento {userName}
    data object ProfileScreen : AppRoutes("profile/{userName}") {
        // Función helper para crear la ruta con el nombre
        fun createRoute(userName: String) = "profile/$userName"
    }

    // Pantalla de configuración
    data object SettingsScreen : AppRoutes("settings")
}