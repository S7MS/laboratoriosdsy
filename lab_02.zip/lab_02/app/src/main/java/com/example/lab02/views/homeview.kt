package com.example.lab02.views

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun HomeView(navController: NavController) {
    // Estado para el nombre que el usuario escribe
    var nombre by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "🏠 Pantalla Principal",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Campo de texto para ingresar nombre
        OutlinedTextField(
            value = nombre,
            onValueChange = { nombre = it },
            label = { Text("Ingresa tu nombre") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Botón para ir a la pantalla de perfil
        Button(
            onClick = {
                // Solo navega si el nombre no está vacío
                if (nombre.isNotBlank()) {
                    navController.navigate("profile/${nombre.trim()}")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = nombre.isNotBlank()  // Deshabilitado si está vacío
        ) {
            Text("Ir a Mi Perfil")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Botón para ir a configuración
        OutlinedButton(
            onClick = {
                navController.navigate("settings")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("⚙️ Configuración")
        }
    }
}


