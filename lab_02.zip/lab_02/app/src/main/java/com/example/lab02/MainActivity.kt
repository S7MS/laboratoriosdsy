package com.example.lab02

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.lab02.AppRoutes
import com.example.lab02.ui.theme.Lab02Theme
import com.example.lab02.views.HomeView
import com.example.lab02.views.ProfileView
import com.example.lab02.views.SettingsView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Lab02Theme {
                // Crear el NavController
                val navController = rememberNavController()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // NavHost: contenedor de todas las pantallas
                    NavHost(
                        navController = navController,
                        startDestination = AppRoutes.HomeScreen.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        // Pantalla Home
                        composable(route = AppRoutes.HomeScreen.route) {
                            HomeView(navController)
                        }

                        // Pantalla Profile con argumento userName
                        composable(
                            route = AppRoutes.ProfileScreen.route,
                            arguments = listOf(
                                navArgument("userName") {
                                    type = NavType.StringType
                                }
                            )
                        ) { backStackEntry ->
                            val userName = backStackEntry.arguments?.getString("userName") ?: ""
                            ProfileView(navController, userName)
                        }

                        // Pantalla Settings
                        composable(route = AppRoutes.SettingsScreen.route) {
                            SettingsView(navController)
                        }
                    }
                }
            }
        }
    }
}