package com.example.labx

import org.junit.Test
import org.junit.Assert.*
import org.junit.Before
import org.mockito.kotlin.mock
import org.mockito.kotlin.whenever
import kotlinx.coroutines.test.runTest
import app.cash.turbine.test
import kotlinx.coroutines.flow.flowOf

/**
 * Test para verificar que todas las dependencias de testing están configuradas correctamente
 */
class TestingDependenciesTest {

    private lateinit var mockService: MockService

    @Before
    fun setup() {
        mockService = mock()
    }

    @Test
    fun `assertEquals basico funciona correctamente`() {
        val resultado = 2 + 2
        assertEquals(4, resultado)
    }

    @Test
    fun `mockito inline mock funciona correctamente`() {
        whenever(mockService.obtenerValor()).thenReturn("Mock funcionando")
        val resultado = mockService.obtenerValor()
        assertEquals("Mock funcionando", resultado)
    }

    @Test
    fun `coroutines runTest funciona correctamente`() = runTest {
        val resultado = suspenderFuncion()
        assertEquals("Coroutine funcionando", resultado)
    }

    @Test
    fun `turbine flow test funciona correctamente`() = runTest {
        val flow = flowOf("Item 1", "Item 2", "Item 3")
        
        flow.test {
            assertEquals("Item 1", awaitItem())
            assertEquals("Item 2", awaitItem())
            assertEquals("Item 3", awaitItem())
            awaitComplete()
        }
    }

    interface MockService {
        fun obtenerValor(): String
    }

    private suspend fun suspenderFuncion(): String {
        return "Coroutine funcionando"
    }
}
